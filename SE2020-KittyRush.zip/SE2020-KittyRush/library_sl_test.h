#ifndef NEW_LIBRARY_WINDOW_TEST_H
#define NEW_LIBRARY_WINDOW_TEST_H

/*
#include <QtTest/QtTest>

#include "scicore/sci_library.h"
class new_library_window_test:public QObject
{
    Q_OBJECT
public:

    void random_act(scicore::sci_library*,int step);

private slots:
    void case1_add_folder();
    void case1_add_folder_data();

    void case2_remove_folder();
    void case2_remove_folder_data();

    void case3_serial_random_act();
    void case3_serial_random_act_data();

    void case4_save_load();
    void case4_save_load_data();
    //void case2_add_and_remove_folder();
    //void case3_abitrary_expand_10000();

};
*/
#endif // NEW_LIBRARY_WINDOW_TEST_H

